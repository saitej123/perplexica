import ChatWindow from '@/components/ChatWindow';
import { Metadata } from 'next';
import { Suspense } from 'react';

export const metadata: Metadata = {
  title: 'SKENSE - Research Assistant',
  description: 'Chat with the internet, chat with SKENSE - Research Assistant.',
};

const Home = () => {
  return (
    <div className="relative min-h-screen">
      {/* Logos Container */}
      <div className="relative">
        {/* Skense Logo on the Top-Left */}
        <img
          src="/assets/skense.png"
          alt="Skense Logo"
          className="absolute top-4 left-2 w-28 h-auto z-50" // Same as before, with increased size and absolute positioning
        />

        {/* WNS Logo on the Top-Right */}
        <img
          src="/assets/wns.png"
          alt="WNS Logo"
          className="absolute top-4 right-2 w-28 h-auto z-50" // Same as before, with increased size and absolute positioning
        />
      </div>

      <Suspense>
        <ChatWindow />
      </Suspense>
    </div>
  );
};

export default Home;
